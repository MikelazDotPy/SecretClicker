import asyncio
from math import pi
from time import sleep
from enum import Enum

import flet as ft
import flet_audio as fta


class Clicker(ft.Column):
    def __init__(self, angle: int = pi / 32) -> None:
        super().__init__()
        self._angle = angle
        self._image = ft.Image(
            src="/images/firsoid.png",
            animate_rotation=ft.Animation(500),
            on_animation_end=self._rotate_loop,
            fit=ft.ImageFit.COVER
        )
        self._image_container = ft.Container(
            content=self._image,
            on_click=self._click,
            on_animation_end=self._unclick,
            animate_scale=ft.Animation(25),
        )

        self._triii = ft.Text(
            value="ТРИИИИИ!!!",
            color=ft.Colors.RED,
            size=100,
            opacity=0.0,
            text_align=ft.TextAlign.CENTER,
            scale=ft.Scale(0.5),
            animate_scale=ft.Animation(400),
            animate_opacity=ft.Animation(150),
            on_animation_end=self._untrii,
        )

        self._say_triii = None

        self._points = 0
        self.click_power = 1
        self.passive = 0

        self._points_t = ft.Text(value=self.points, size=40)

        self.controls = [
            ft.Container(
                content=ft.Column(
                    [
                        self._points_t,
                        ft.Stack(
                            [self._image_container, self._triii]
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                alignment=ft.alignment.center
            )
        ]
    
    @property
    def points(self):
        return self._points
    
    @points.setter
    def points(self, new_val):
        if new_val > self._points and (new_val - self.points >= 3 or new_val % 3 == 0):
            self._triii.opacity = 1
            self._triii.scale = ft.Scale(1)
            self._triii.update()

        self._points = new_val
        self._points_t.value = self._points
        for x in self.upgs:
            x._update_btn()
        self._points_t.update()
    
    async def _add_pasive(self):
        while True:
            self.points += self.passive
            await asyncio.sleep(1)
    
    def _untrii(self, e) -> None:
        self._triii.scale = ft.Scale(0.5)
        self._triii.opacity = 0.0
        self._triii.update()

    def _click(self, e) -> None:
        self.points += self.click_power
        self._image_container.scale = ft.Scale(0.9)
        self._image_container.update()
    
    def _unclick(self, e) -> None:
        self._image_container.scale = ft.Scale(1)
        self._image_container.update()
    
    def _rotate_loop(self, e) -> None:
        self._image.rotate = ft.Rotate(self._angle)
        self._angle *= -1
        self._image.update()
    
    def post_init(self, upgs, page) -> None:
        self._rotate_loop(None)
        self.upgs = upgs

class Upgrade(ft.Container):
    class Type(Enum):
        CLICK_POWER = 1
        AUTO_CLICK = 2

    def __init__(self, name, price, about, power, type, clicker: Clicker, aud):
        super().__init__(
            bgcolor=ft.Colors.WHITE,
            border_radius=ft.border_radius.all(10),
            padding=ft.padding.all(15),
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=5,
                color=ft.Colors.BLACK38,
                offset=ft.Offset(0, 0),
                blur_style=ft.ShadowBlurStyle.NORMAL,
            ),
            border=ft.border.all(1, ft.Colors.GREY_300),
            width=300
        )

        self.aud = aud
        self.clicker = clicker

        self.power = power
        self._count = 0
        self._count_t = ft.Text(value=f"Куплено: {self._count}", italic=True)
        self._price = price
        self._price_t = ft.Text(value=f"${self._price}", color=ft.Colors.GREEN)
        self._btn = ft.Button("  Купить  ", disabled=True, on_click=self._on_click)
        self.type = type

        self.content = ft.Column(
            [
                ft.Text(value=name, weight=ft.FontWeight.BOLD, size=30),
                self._count_t,
                self._price_t,
                ft.Text(value=about),
                self._btn
            ], spacing=2
        )
    
    def _on_click(self, e) -> None:
        self.clicker.points -= self._price
        self._price += self._price // 2
        self._price_t.value = f"${self._price}"
        self._price_t.update()
        self._count += 1
        self._count_t.value = f"Куплено: {self._count}"
        self._count_t.update()
        self.aud.play()

        if self.type == self.Type.AUTO_CLICK:
            self.clicker.passive += self.power
        else:
            self.clicker.click_power += self.power
    
    def _update_btn(self) -> None:
        if self.clicker.points >= self._price:
            self._btn.disabled = False
        else:
            self._btn.disabled = True
        self._btn.update()


def main(page: ft.Page):
    page.title = "Фирсов Кликер"
    page.padding = 10
    page.theme_mode = ft.ThemeMode.LIGHT
    say_triii = fta.Audio(
            src="/audio/tri.mp3", volume=1
        )
    page.overlay.append(say_triii)

    # def repeat(e):
    #     if e.state == fta.AudioState.COMPLETED:
    #         ost.play()

    # ost = fta.Audio(
    #         src="/audio/sound.mp3",
    #         autoplay=True, on_state_changed=repeat, volume=0.01
    #     )

    # page.overlay.append(ost)
    page.update()

    clicker = Clicker()
    upgs = [
        Upgrade("ПИшник", 33, "Я очень люблю ПИшников. +1 лысины в секунду", 1, Upgrade.Type.AUTO_CLICK, clicker, say_triii),
        Upgrade("ПМИшник", 333, "Я уничтожу вас всех. +3 к силе клика", 3, Upgrade.Type.CLICK_POWER, clicker, say_triii),
        Upgrade("Мазь для лысина", 3333, "Теперь она блестит. +33 лысины в секунду", 33, Upgrade.Type.AUTO_CLICK, clicker, say_triii),
        Upgrade("ЗАЩИТА ЗАВЕРШЕНА С ТРЕМЯ...", 33333, "С чем ты завершил защиту?)). +333 лысины в секунду", 333, Upgrade.Type.AUTO_CLICK, clicker, say_triii),
    ]
    upgrades = ft.Container(
        content=ft.ListView(
            controls=upgs,
            spacing=10,
            padding=10,
            expand=True
        ),expand=True
    )
    up2 = [upgrades]
    desktop_layout = ft.Row(
        [
            ft.Column([ft.Container(clicker, expand=True, alignment=ft.alignment.center)], expand=6),
            ft.Column(up2, scroll=ft.ScrollMode.AUTO, expand=4)
        ],
        expand=True, alignment=ft.MainAxisAlignment.CENTER
    )
    mobile_layout = ft.Column(
        [
            clicker,
            ft.Container(ft.Column(up2, scroll=ft.ScrollMode.AUTO), expand=True)
        ],
        expand=True, alignment=ft.MainAxisAlignment.CENTER
    )

    page.add(desktop_layout)
    page.add(mobile_layout)
    
    def handle_resize(e=None):
        desktop_layout.visible = page.width >= 800
        mobile_layout.visible = page.width < 800
        page.update()
        sleep(0.1)
        clicker._rotate_loop(None)

    handle_resize()
    page.on_resized = handle_resize
    sleep(0.1)
    clicker.post_init(upgs, page)
    page.run_task(clicker._add_pasive)


ft.app(target=main, assets_dir="assets", view=ft.WEB_BROWSER)