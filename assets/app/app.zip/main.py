import micropip
await micropip.install("flet")

from math import pi
from time import sleep

import flet as ft


class Clicker(ft.Column):
    def __init__(self, angle: int = pi / 32) -> None:
        super().__init__()
        self._angle = angle
        self._image = ft.Image(
            src="/images/firsoid.png",
            animate_rotation=ft.Animation(500),
            on_animation_end=self._rotate_loop,
            fit=ft.ImageFit.COVER
        )
        self._image_container = ft.Container(
            content=self._image,
            on_click=self._click,
            on_animation_end=self._unclick,
            animate_scale=ft.Animation(100),
        )

        self._triii = ft.Text(
            value="ТРИИИИИ!!!",
            color=ft.Colors.RED,
            size=100,
            opacity=0.0,
            text_align=ft.TextAlign.CENTER,
            scale=ft.Scale(0.5),
            animate_scale=ft.Animation(400),
            animate_opacity=ft.Animation(150),
            on_animation_end=self._untrii,
        )

        self._points = 0
        self.click_power = 1

        self._points_t = ft.Text(value=self.points, size=40)

        self.controls = [
            ft.Container(
                content=ft.Column(
                    [
                        self._points_t,
                        ft.Stack(
                            [self._image_container, self._triii]
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                alignment=ft.alignment.center
            )
        ]
    
    @property
    def points(self):
        return self._points
    
    @points.setter
    def points(self, new_val):
        if new_val > self._points and (new_val - self.points >= 3 or new_val % 3 == 0):
            self._triii.opacity = 1
            self._triii.scale = ft.Scale(1)
            self._triii.update()

        self._points = new_val
        self._points_t.value = self._points
        self._points_t.update()
    
    def _untrii(self, e) -> None:
        self._triii.scale = ft.Scale(0.5)
        self._triii.opacity = 0.0
        self._triii.update()

    def _click(self, e) -> None:
        self.points += self.click_power
        self._image_container.scale = ft.Scale(0.9)
        self._image_container.update()
    
    def _unclick(self, e) -> None:
        self._image_container.scale = ft.Scale(1)
        self._image_container.update()
    
    def _rotate_loop(self, e) -> None:
        self._image.rotate = ft.Rotate(self._angle)
        self._angle *= -1
        self._image.update()
    
    def post_init(self) -> None:
        self._rotate_loop(None)


def main(page: ft.Page):
    page.title = "Фирсов Кликер"
    page.padding = 10
    page.theme_mode = ft.ThemeMode.LIGHT
    clicker = Clicker()
    page.add(clicker)
    sleep(0.1)
    clicker.post_init()

ft.app(target=main, assets_dir="assets", view=ft.WEB_BROWSER)